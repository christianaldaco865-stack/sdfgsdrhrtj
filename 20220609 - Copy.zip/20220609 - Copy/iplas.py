from datetime import datetime
import os, sys
import params as ps

if not ps.tsp in os.listdir(ps.iplas_root):
	os.system('mkdir {}\\{}'.format(ps.iplas_root, ps.tsp))

# os.system('net use \\10.2.2.2 /user:t1logupload t1log789#')

def DATA_2_iPLas(ISN, DATA, SFIS_message, Start_time, End_time, errorcode=''):
	iPlas_format = 'TEST,STATUS,VALUE,UCL,LCL,CYCLE\n'
	iPlas_format += 'ISN,,{}\n'.format(ISN)
	iPlas_format += 'ProducerVersion,,{}\n'.format(ps.iplas_version)
	iPlas_format += 'SFIS message,,{}\n'.format(SFIS_message)
	iPlas_format += 'Project,,{}\n'.format(ps.iplas_project)
	iPlas_format += 'Line,,{}\n'.format(ps.iplas_line)
	iPlas_format += 'TSP,,{}\n'.format(ps.tsp)
	iPlas_format += 'Type,,Online\n'
	iPlas_format += 'Slot,,\n'
	iPlas_format += 'DeviceId,,{}\n'.format(ps.deviceID)
	iPlas_format += 'Model,,FCT\n'
	iPlas_format += 'Test Start Time,,{}\n'.format(Start_time)
#------------------------------------------------- DATA process
	datas = DATA.split('\n')[1:]
	print(datas)
	try:
		datas.remove('')
	except:
		pass
	error_item = []
	for data in datas:
		value = [x.strip() for x in data.split(',')]
		if value[1] == '1':
			iPlas_format += '{}, 1'.format(value[0])
		else:
			iPlas_format += '{}, 0'.format(value[0])
			error_item.append(value[0])
		for v in value[2:]:
			iPlas_format += ', {}'.format(v)
		iPlas_format += '\n'

#------------------------------------------------- Errorcode&Test Status process
	if errorcode == '':
		iPlas_format += 'ErrorCode,,Pass\n'
		iPlas_format += 'Test Status,,PASS\n'
	else:
		iPlas_format += 'ErrorCode,,{}\n'.format(errorcode)
		for er in error_item:
			iPlas_format += 'ErrorMessage,,{}\n'.format(er)
		iPlas_format += 'Test Status,,FAIL\n'

	iPlas_format += 'Test end Time,,{}\n'.format(End_time)
	iPlas_format += 'CallerSendTime,,{}\n'.format(datetime.now().strftime('%Y/%m/%d %H:%M:%S'))

#------------------------------------------------- Save Log&Output Result
	with open('tmp.csv'.format(ps.iplas_root, ps.tsp, ISN.replace(':',''), datetime.now().strftime('%Y-%m-%d_%H%M')), 'w') as f:
		f.write(iPlas_format)
		
	os.system('move tmp.csv {}\\{}\\{}_{}.csv'.format(ps.iplas_root, ps.tsp, ISN.replace(':',''), datetime.now().strftime('%Y-%m-%d_%H%M')))
	# iplas.send_ts_msg(iPlas_format.encode(), ps.iplas_tsp)
	return iPlas_format

if __name__ == '__main__':
	from ctypes import *
	
	iplas = CDLL('D:\\pega\\iplas\\Producer_Sdk_2.1.0.16\\win32\\pega_producer.dll')
	version = c_char_p()
	sys.exit()
	iplas.get_version(byref(version))
	version = version.value.decode()
	iplas.initialize(False)
	iplas.set_deviceid(ps.iplas_TestPC.encode())

	Start_time = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
	End_time = datetime.now().strftime('%Y/%m/%d %H:%M:%S')
	
	sfis_message = '1SFIS:ISN OK!!(U)(SM) TEST DATA:SAVED! STATUS:[1] (TSP_TRESULT)217093'
	with open(sys.argv[1]) as f:
		log = f.read()
		print(log)
	DATA_2_iPLas(sys.argv[2], log, sfis_message, Start_time, End_time, errorcode='')
	# print(iplas.send_msg(log.encode(), ps.tsp))


	