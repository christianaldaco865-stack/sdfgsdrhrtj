import os
import tkinter as tk
from  tkinter import ttk

class Exe_tree:
    flag = False
    x_rollbar_flag = [False,0]

    def __init__(self, win, exe_list):
        # win.geometry('300x560')
        self.tree=ttk.Treeview(win, show='headings')
        self.tree.tag_configure('Pass', foreground="green")
        self.tree.tag_configure('Fail', foreground="red")
        self.tree["columns"]=('Item', 'Status', 'Value', 'Upper Bound', 'Lower Bound')
        self.ysb=ttk.Scrollbar(win,orient="vertical",command=self.tree.yview())  #y滚动条
        self.ysb.config(command=self.tree.yview)
        self.xsb = ttk.Scrollbar(win, orient="horizontal",command=self.tree.xview()) #x滚动条
        self.xsb.config(command=self.tree.xview)
        self.tree.configure(yscroll=self.ysb.set,xscroll=self.xsb.set)

        self.tree.column("Item",width=160)
        self.tree.column("Status",width=40)
        self.tree.column("Value",width=80)
        self.tree.column("Upper Bound",width=80)
        self.tree.column("Lower Bound",width=80)

        self.tree.heading("Item",text="Item")
        self.tree.heading("Status",text="Status")
        self.tree.heading("Value",text="Value")
        self.tree.heading("Upper Bound",text="UCL")
        self.tree.heading("Lower Bound",text="LCL")


    def popup(self, event):
        if self.tree.identify_row(event.y) not in self.tree.selection():
            self.menubar_0.x = event.x
            self.menubar_0.y = event.y
            self.menubar_0.menubar.post(event.x_root,event.y_root)
        else:
            self.menubar_1.x = event.x
            self.menubar_1.y = event.y
            self.menubar_1.menubar.post(event.x_root,event.y_root)


    def child_set(self, row):
        it = [i for i in self.tree.item(row, "values")]
        it[0] = self.text_input.get()
        self.tree.item(row, values=it)
        self.text_input.set('')
        self.entryedit.destroy()


    def treeview_sort_column(self, tv, col, reverse):#Treeview、列名、排列方式
        if col != 'Order':
            l = [(tv.set(k, col), k) for k in tv.get_children('')]
            l.sort(reverse=reverse)#排序方式
            for index, (val, k) in enumerate(l):#根据排序后索引移动
                tv.move(k, '', index)
            tv.heading(col, command=lambda: self.treeview_sort_column(tv, col, not reverse))#重写标题，使之成为再点倒序的标题
        else:
            l = []
            for item in tv.get_children():
                l.append(tv.item(item, 'values'))
            self.re_import(l)
