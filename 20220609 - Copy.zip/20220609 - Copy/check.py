import urllib3
import base64
import NA.params as ps
from datetime import datetime, timedelta
import traceback

http = urllib3.PoolManager()

month_dict = dict(  Jan = "01",
                    Feb = "02",
                    Mar = "03",
                    Apr = "04",
                    May = "05",
                    Jun = "06",
                    Jul = "07",
                    Aug = "08",
                    Sep = "09",
                    Oct = "10",
                    Nov = "11",
                    Dec = "12"

)

def getSFISTime():
	date      = http.request('GET', 'http://%s'%(ps.url.split('/')[2])).getheader('date')
	date      = date.split()

	Year      = date[3]
	Month     = month_dict[date[2]]
	Day       = date[1]
	newtime   = date[4]

	GMT_TIME  = "{}{}{} {}".format(Year, Month, Day, newtime)
	GMT_TIME  = datetime.strptime(GMT_TIME, '%Y%m%d %H:%M:%S')
	timeToSet = GMT_TIME + timedelta(hours=8)
	strdate, strtime = str(timeToSet).split(' ')

	return strdate, strtime

def writeBinFile():
	print('Check Pass! Save Data.')
	nowDate, nowTime = getSFISTime()
	with open('checkDate.bin', 'wb') as f:
		encode = base64.encodestring(nowDate.encode())
		f.write(encode)
    
def checkBinFile():
	try:
		nowDate, nowTime = getSFISTime()
		with open('checkDate.bin', 'rb') as f:
			recordDate = base64.decodestring(f.readline())
		if nowDate == recordDate.decode():
			return True
		else:
			if int(nowTime.split(':')[0]) < 8:
				return True
		return False
	except:
		message = traceback.format_exc()
		print(message)
		return False

if __name__ == "__main__":
	checkBinFile()