import params as ps
from Denkovi import dae_RelayBoard

dr_16 = dae_RelayBoard.DAE_RelayBoard(dae_RelayBoard.DAE_RELAYBOARD_TYPE_16)
dr_16.initialise(ps.relay_com_16)
dr_16.setAllStatesOff()

dr_8 = dae_RelayBoard.DAE_RelayBoard(dae_RelayBoard.DAE_RELAYBOARD_TYPE_8)
dr_8.initialise()
dr_8.setAllStatesOff()

def turn_relay_16(channel):
	dr_16.setAllStatesOff()
	for i in channel:
		dr_16.setState(i, True)

def turn_relay_8(channel):
	dr_8.setAllStatesOff()
	for i in channel:
		dr_8.setState(i, True)

# def turn_relay(channel, ch=False, ON_OFF=True):
# 	if ch:
# 		dr_16.setAllStatesOff()
# 		for i in channel:
# 			if ON_OFF:
# 				dr_16.setState(i, True)
# 			else:
# 				dr_16.setState(i, False)
# 	else:
# 		dr_8.setAllStatesOff()
# 		for i in channel:
# 			if ON_OFF:
# 				dr_8.setState(i, True)
# 			else:
# 				dr_8.setState(i, False)


def reset_all():
	dr_16.setAllStatesOff()
	dr_8.setAllStatesOff()

if __name__ == '__main__':
	import time
	turn_relay_8([1,2,5,6])
	time.sleep(3)
	reset_all()