from pysimplesoap.client import SoapClient
import sys, os, time
import NA.params as ps

url = ps.url
flag = True

def cooling_time_judge(SN):
    if flag:
        message = sfis.WTSP_GETVERSION(SN, ps.deviceID, type='TSP_RESULT', ChkData='TEST 9')
        print('GET VERSION:', message)
        if message[0] != '1':
            return False
        sub_message = message.split(';')[-1][5:24]
        struct_time = time.strptime(sub_message, "%Y/%m/%d %H:%M:%S")
        time_stamp = int(time.mktime(struct_time))

        if int(time.time())-time_stamp > ps.cooling_time:
            return False

        return True
    else:
        return False


class sfis_tool():
    def __init__(self, url, DeviceID='', ProgramID='TSP_PND', ProgramPassword='g4sl5d',
        password='pegatron', TSP='AI0'):
        try:
            # if not flag:
            self.fake_return_value = {'WTSP_LOGINOUTResult':'1', 'WTSP_RESULTResult':'1', 'WTSP_CHKROUTEResult':'1'}
            self.url = url
            self.device = DeviceID
            self.ProgramID = ProgramID
            self.ProgramPassword = ProgramPassword
            self.password = password
            self.TSP = TSP
            self.client = SoapClient(wsdl=url, trace=False)
            self.data = 'TEST,TSTATUS,TVALUE\n'

        except Exception as e:
            print(e)
            print('SFIS IP:{} connect Error!'.format(ps.url))
            os.system('pause')
            sys.exit()

    def WTSP_LOGIN(self, op, device):
        if not flag:
            return self.fake_return_value['WTSP_LOGINOUTResult']
        login = self.client.WTSP_LOGINOUT(programId=self.ProgramID,
                                    programPassword=self.ProgramPassword,
                                    op=op,
                                    password=self.password,
                                    device=device,
                                    TSP=self.TSP,
                                    status=1)
        print(login)
        return login['WTSP_LOGINOUTResult']
    def WTSP_LOGOUT(self, op, device):
        if not flag:
            return self.fake_return_value['WTSP_LOGINOUTResult']
        login = self.client.WTSP_LOGINOUT(programId=self.ProgramID,
                                    programPassword=self.ProgramPassword,
                                    op=op,
                                    password=self.password,
                                    device=device,
                                    TSP=self.TSP,
                                    status=2)
        print(login)
        return login['WTSP_LOGINOUTResult']
        
    def WTSP_RESULT(self, isn, device, TSP='',Data='', Error='', Status=1):
        if not flag:
            return self.fake_return_value['WTSP_RESULTResult']
        if Data == '':
            Data = self.data
        if TSP == '':
            TSP = self.TSP
        login = self.client.WTSP_RESULT(programId=self.ProgramID,
                                    programPassword=self.ProgramPassword,
                                    ISN=isn,
                                    error=Error,
                                    device=device,
                                    TSP=TSP,
                                    data=Data,
                                    status=1,
                                    CPKFlag='')
        print(login)
        return login['WTSP_RESULTResult']

    def WTSP_LINK(self, isn_pcb, isn_tla, device, data='', Error=''):
        if not flag:
            return self.fake_return_value['WTSP_RESULTResult']
        if data == '':
            data = ('TEST,TSTATUS,TVALUE\n#SAVE:KP,AUTOKPLK,{0}\n').format(isn_pcb)


        login = self.client.WTSP_RESULT(programId=self.ProgramID,
                                    programPassword=self.ProgramPassword,
                                    ISN=isn_tla,
                                    error=Error,
                                    device=device,
                                    TSP=self.TSP,
                                    data=data,
                                    status=1,
                                    CPKFlag='')
        print(login)
        return login['WTSP_RESULTResult']

    def WTSP_CHKROUTE(self, ISN, device):
        if not flag:
            return self.fake_return_value['WTSP_CHKROUTEResult']
        login = self.client.WTSP_CHKROUTE(programId=self.ProgramID,
                                    programPassword=self.ProgramPassword,
                                    ISN=ISN,
                                    device=device,
                                    checkFlag='',
                                    checkData='',
                                    type=1)
        print(login)
        return login['WTSP_CHKROUTEResult']

    def WTSP_GETVERSION(self, ISN, device, type='ITEMINFO', ChkData='', ChkData2=''):
        login = self.client.WTSP_GETVERSION(programId=self.ProgramID,
                                    programPassword=self.ProgramPassword,
                                    ISN=ISN,
                                    device=device,
                                    type=type,
                                    ChkData=ChkData,
                                    ChkData2=ChkData2)

        return login['WTSP_GETVERSIONResult']

sfis = sfis_tool(ps.url)

if __name__ == '__main__':
    sn = 'P1490374-10-D:SB7S21161J03725'
    print(cooling_time_judge(sn))
    # DeviceID='216017'
    # sfis = sfis(url)
    #sfis.WTSP_LOGIN('LA1801008', DeviceID)
    # print(sfis.WTSP_CHKROUTE(tla, DeviceID))
    # print(sfis.WTSP_GETVERSION(sn, DeviceID, type='TSP_RESULT', ChkData='TEST 9'))

    # sfis.WTSP_RESULT(tla, DeviceID, TSP=ps.tsp, Data=DATA, Error='IPV01')
    #sfis.WTSP_LINK(pcba, tla, DeviceID)
