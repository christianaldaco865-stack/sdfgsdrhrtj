import os
import datetime

#------------------------------------------------------------- mkdir "Log"
Local_list = os.listdir(os.getcwd())
if not 'Log' in Local_list:
    os.system('mkdir Log')

#------------------------------------------------------------- Global SN, date and file name record
def update_record(sn='Test'):
    global SN, date, file_name

    SN = sn.replace(':', '')
    date = datetime.datetime.now().strftime('%Y-%m-%d')
    hora = datetime.datetime.now().strftime('%H%M%S')
    file_name = 'Log\\{}_{}_{}.csv'.format(SN, date,hora)
    print(SN, date, file_name)

#------------------------------------------------------------- Record SN, ErrorCode, Data
def output_SFIS(errorcode, data):
    global SN, date, file_name
    with open(file_name, 'a') as csv:
        if errorcode == '':
            csv.write('ReadISN, 0, {}\n'.format(SN))
            csv.write(data)
        else:
            csv.write('ReadISN, {}, {}\n'.format(errorcode, SN))
            csv.write(data)

#------------------------------------------------------------- Record other message
def output_message(message):
    global SN, date, file_name
    with open(file_name, 'a') as csv:
        csv.write(str(message))
		
#
#   Lineas agregadas para renombrar el script
#

def rename_log(estatus):

    file_name_new = file_name[:-4] + "_" + estatus + ".csv"
    os.rename(file_name, file_name_new)