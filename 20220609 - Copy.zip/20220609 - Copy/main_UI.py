﻿import os, sys, time
import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showinfo
import threading
from check import *
import SFIS
import UI_tree as ut
import myfunc as m
import traceback
# from iplas import Iplas
from datetime import datetime
import NA.main as main
import NA.params as ps
from NA.latch import Latch, myins
from NA.relay import *
 
def testProcess(UI, flag=False):
	errorcode = []
	DATA = ''
	message = 'Please put Golden Sample and press button to start Test!\n請放置正常樣本並按下按鈕開始測試'
	showinfo('message', message)

	# UI.update_result.set('WAIT')

	message = 'Please put Error Sample and press button to continue Test!\n請放置異常樣本並按下按鈕繼續測試'
	showinfo('message', message)

	return len(errorcode) == 8, DATA

def single_Testing_process(UI, F):
	errorcode, DATA = F.start()
	UI.DATA_2_list(F.DATA)
	if isinstance(errorcode, list):
		if len(errorcode) < 1:
			return '', DATA	
		return errorcode[0], DATA
	else:
		return errorcode, DATA

class sfis_tool:
	def __init__(self):
		self.ver = '2022/03/24'
		self.op_ui()
		self.op = self.op.get().strip().upper()

		self.win = tk.Tk()
		self.win.update_idletasks()

		s = ttk.Style()
		s.configure('TNotebook.Tab', font=('Helvetica -20 bold',20), width=10)

		self.win.title('NEW EVP002(NA) Tool {}'.format(self.ver))
		self.win.geometry('1080x660')
		self.win.configure()

		style = ttk.Style(self.win)
		style.theme_use("clam")

		sn_lab = tk.Label(self.win, font=('Helvetica -20 bold', 20), text='SN:')
		sn_lab.place(relwidth=0.15,relheight=0.075,relx=0.01,rely=0.1)

		self.sn = tk.StringVar()
		self.sn.set('')
		self.snBox = tk.Entry(self.win, show='', textvariable=self.sn)
		self.snBox.config(font=('Helvetica -20 bold', 20))
		self.snBox.bind('<Return>', lambda x:self.create_thread())
		self.snBox.place(relwidth=0.45,relheight=0.075,relx=0.16,rely=0.1)
		self.snBox.focus()

		self.test_flag = False

		self.time_lab = tk.Label(self.win, font=20, text=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))
		self.time_lab.place(relwidth=0.24,relheight=0.07,relx=0.75,rely=0.92)
		self.time_lab.after(1000, self.get_time_string)

		self.update_result = tk.StringVar()
		self.update_result.set('WAIT')
		self.update_result_lab = tk.Label(self.win, font=(None, 50), textvariable=self.update_result, fg='white',bg='light blue')
		self.update_result_lab.place(relwidth=0.25,relheight=0.15,relx=0.7,rely=0.75)

		self.sfis_state_text = tk.StringVar()
		self.sfis_button = tk.Button(font=('Fixdsys', 25),textvariable=self.sfis_state_text, command=self.sfis_state, state='normal')
		self.sfis_button.place(relwidth=0.1,relheight=0.075,relx=0.62,rely=0.1)
		self.sfis_state(flag=False)

		self.return_value = tk.StringVar()
		self.return_value.set('')

		self.tree = ut.Exe_tree(self.win, [])
		self.tree.tree.place(relwidth=0.65,relheight=0.55,relx=0.01,rely=0.42)
		self.tree.ysb.place(width=20,relheight=0.55,relx=0.66,rely=0.42)

		self.win.bind('<ButtonRelease-3>', self.create_menu)
		self.menu = tk.Menu(self.win, tearoff=0)
		#------------------------  NA
		self.menu.add_command(label='Connect Test', command=lambda:self.create_thread(function=main.preTest_func))
		self.menu.add_command(label='Hi-Pot', command=lambda:self.create_thread(function=main.Hipot_func))
		self.menu.add_command(label='IR', command=lambda:self.create_thread(function=main.IR_func))
		self.menu.add_command(label='Cycle Latch', command=lambda:self.create_thread(function=Latch))
		self.menu.add_command(label='Resistance 1,2,3', command=lambda:self.create_thread(function=main.Resistance_1_2_3))
		self.menu.add_command(label='Resistance 7,8,10,11', command=lambda:self.create_thread(function=main.Resistance_7_8_10_11))
		self.menu.add_command(label='Resistance 9(Heating)', command=lambda:self.create_thread(function=main.Resistance_9))

		self.win.deiconify()
		self.win.mainloop()

		myins.close()

	def create_menu(self, event):
		self.menu.post(event.x_root,event.y_root)

	def sfis_state(self, flag=True):
		if flag:
			SFIS.flag = not SFIS.flag
		if SFIS.flag:
			self.sfis_state_text.set('online')
			self.sfis_button.config(bg='orange')
		else:
			self.sfis_state_text.set('offline')
			self.sfis_button.config(bg='yellow')

	def initial(self):
		self.test_flag = True
		self.snBox.config(state='disable')
		self.update_result.set('RUN')
		self.update_result_lab.config(bg='orange')
		self.errorcode = ''
		self.DATA = 'TEST,STATUS,VALUE,UCL,LCL\n'

		m.update_record(self.sn.get().strip())
		m.output_message('Ver., {}\n'.format(self.ver))
		for i in self.tree.tree.get_children():
			self.tree.tree.delete(i)

	def UI_reset(self, flag=0, sf=True):
		self.snBox.config(state='normal')
		self.sn.set('')
		self.test_flag = False
		self.snBox.focus()

		if flag == 0:
			self.update_result.set('PASS')
			self.update_result_lab.config(bg='green')
			estado_unid = "Passed"
			
			
		elif flag == 1:
			self.update_result.set(self.errorcode)
			self.update_result_lab.config(bg='red')
			estado_unid = "Failed"
			
			
		else:
			self.update_result.set('ERROR')
			self.update_result_lab.config(bg='pink')
			estado_unid = "Error"
			
			

		print(self.op, ps.deviceID)
		if sf:
			ret = SFIS.sfis.WTSP_LOGOUT(self.op, ps.deviceID)
			m.output_message(ret+'\n')
			if estado_unid == "Passed":
				m.rename_log("Passed")
			if estado_unid == "Failed":
				m.rename_log("Failed")
			if estado_unid == "Error":
				m.rename_log("Error")

		print('UI-Reset FIN')

	def sfis_login(self, id, win):
		self.op.set(id.get().upper().strip())
		print('Input ID:', self.op.get())

		try:
			ret = SFIS.sfis.WTSP_LOGIN(id.get().upper().strip(), ps.deviceID)
			self.return_value.set(ret)
			if ret[0] == '1':
				self.return_value.set('ID {} 已登入，SFIS 連線正常'.format(id.get()))
				win.destroy()
			elif ret.find('Twice') > 0:
				SFIS.sfis.WTSP_LOGOUT(self.op.get(), ps.deviceID)
				self.sfis_login(id, win)
			else:
				self.return_value.set('SFIS 連線正常，但ID {}登入Device {}失敗'.format(id.get(), ps.deviceID))
				self.op.set('')

		except Exception as e:
			print(traceback.format_exc())
			self.op.set('')
			m.output_message('\n{}\n'.format(traceback.format_exc()))
			self.return_value.set(str(e)+'\n'+'SFIS 連線失敗')

	def op_ui(self):
		win = tk.Tk()
		win.title('Operator ID input')
		win.geometry('600x300')
		win.configure()

		self.op = tk.StringVar()
		self.op.set('')
		op_lab = tk.Label(win, font=('Times -20 bold', 20), text='OP ID:')
		op_lab.place(relwidth=0.2,relheight=0.2,relx=0.01,rely=0.1)

		inputBox = tk.Entry(win, show='')
		inputBox.config(font=('Helvetica -20 bold', 35),  textvariable=self.op)
		inputBox.bind('<Return>',lambda x: self.sfis_login(inputBox, win))
		inputBox.place(relwidth=0.6,relheight=0.2,relx=0.22,rely=0.1)
		inputBox.focus()

		self.return_value = tk.StringVar()
		self.return_value.set('')
		self.message = tk.Label(win, font=('Helvetica -20 bold', 15), fg='red',textvariable=self.return_value, wraplength=450)
		self.message.place(relwidth=0.79,relheight=0.4,relx=0.11,rely=0.5)

		win.deiconify()
		win.mainloop()

		print(self.op.get())
		if self.op.get() == '':
			sys.exit()

	def DATA_2_list(self, DATA):
		items = DATA.split('\n')
		try:
			items.remove('')
		except:
			pass

		name = []
		res = []
		value = []
		ucl = []
		lcl = []

		for item in items:
			data = item.split(',')
			name.append(data[0])
			if data[1].strip() == '1':
				res.append('Pass')
			else:
				res.append('Fail')
			value.append(data[2])
			try:
				ucl.append(data[3])
			except:
				ucl.append('')
			try:
				lcl.append(data[4])
			except:
				lcl.append('')

		for j in range(len(name)):
			i = len(self.tree.tree.get_children())
			# self.tree.tree.insert("","end",values=(self.sn.get(), name[j], res[j], value[j], ucl[j], lcl[j]))
			self.tree.tree.insert("","end",values=(name[j], res[j], value[j], ucl[j], lcl[j]))

			for i in range(98,100):
				self.tree.tree.yview_moveto(i/100)
				self.tree.tree.update()

	def main_Test(self):
		self.sfis_button.config(state="disabled")
		try:
			errorcode, DATA = main.testProcess(self)
		except:
			reset_all()
			showinfo('Error message', traceback.format_exc())
			self.UI_reset(flag=2)
			return 

		if DATA == '':
			self.errorcode = 'FAIL'
			self.UI_reset(flag=1)

		self.errorcode = errorcode
		self.DATA += DATA

		ret = SFIS.sfis.WTSP_RESULT(self.sn.get(), ps.deviceID,Data=self.DATA, Error=self.errorcode)

		if ret.find('[INSERTION EXTRACTION]') > -1:
			showinfo('message', '請加驗[INSERTION EXTRACTION]')

		m.output_message(ret+'\n')
		m.output_SFIS(self.errorcode, DATA)
		self.sfis_button.config(state="normal")

		if ret[0].strip() != '1':
			showinfo('message', '{} update SFIS Fail!\n{}'.format(self.sn.get().strip(), ps.deviceID, ret))
			self.UI_reset(flag=2)
			return False

		if self.errorcode != '':
			self.UI_reset(flag=1)
		else:
			self.UI_reset()

	def single_Test(self, function):
		errorcode, DATA = single_Testing_process(self, function)
		self.errorcode = errorcode
		self.DATA = self.DATA + DATA
		print('Errorcode:', self.errorcode)
		print(self.DATA)

		m.output_SFIS(self.errorcode, DATA)

		if self.errorcode != '':
			self.UI_reset(flag=1, sf=False)
		else:
			self.UI_reset(sf=False)

	def create_thread(self, function=None):
		if function==None:
			if self.test_flag or self.sn.get().strip()=='':
				return 0

		self.initial()

		m.output_message('Input Box insert,{}\n'.format(self.sn.get().strip()))

		if function==None:
			ret = SFIS.sfis.WTSP_LOGIN(self.op, ps.deviceID)

			if ret.find('Twice') > 0:
				ret = SFIS.sfis.WTSP_LOGIN(self.op, ps.deviceID)
				m.output_message(ret+'\n')

			elif ret[0] != '1':
				m.output_message(ret+'\n')
				showinfo('message', 'ID:{} login Device:{} Fail!\n{}'.format(self.op, ps.deviceID, ret))
				self.UI_reset(flag=2)
				return False

			else:
				m.output_message(ret+'\n')

			ret = SFIS.sfis.WTSP_CHKROUTE(self.sn.get(), ps.deviceID)
			m.output_message(ret+'\n')
			if ret[0] != '1':
				showinfo('message', '{} Check route Fail!\n{}'.format(self.sn.get().strip(), ret))
				self.UI_reset(flag=2)
				return False
			
			if SFIS.cooling_time_judge(self.sn.get()):
				showinfo('message', 'The cooldown has not yet been completed!')
				self.UI_reset(flag=2)
				return False

			threading.Thread(target=self.main_Test).start()
			# self.main_Test()

		else:
			self.UI_reset(sf=False)
			self.sn.set('Test')
			self.initial()
			threading.Thread(target=self.single_Test, args=[function]).start()

	def get_time_string(self, flag=False):
		currentTime=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
		if flag:
			return currentTime
		self.time_lab.config(text=currentTime)
		self.win.update()
		self.time_lab.after(1000, self.get_time_string)

if __name__ == '__main__':
	sfis_tool()
