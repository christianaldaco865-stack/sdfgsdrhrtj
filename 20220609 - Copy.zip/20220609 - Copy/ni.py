import nidaqmx
from nidaqmx.constants import (
    LineGrouping)

class NI_USB_6000:
    def __init__(self):
        with nidaqmx.Task() as task:
            try:
                task.do_channels.add_do_chan(
                    'Dev1/port0/line0:3',
                    line_grouping=LineGrouping.CHAN_FOR_ALL_LINES)

                task.write([True, True, True, True], auto_start=True)
                task.write(8)
            except nidaqmx.DaqError as e:
                print(e)
                print('NI USB 6000 Connect Error!')
    def read(self, channel):
        if channel > 7 or channel < 0:
            channel = 0
        with nidaqmx.Task() as task:
            task.ai_channels.add_ai_voltage_chan("Dev1/ai{}".format(channel))
            data = task.read()
            # print('Dev1/ai{} = {}'.format(channel, data))

        return data

    def write(self, channel):
        with nidaqmx.Task() as task:
            task.do_channels.add_do_chan(
                'Dev1/port0/line0:3',
                line_grouping=LineGrouping.CHAN_FOR_ALL_LINES)

            print(task.write(channel))


usb_6000 = NI_USB_6000()
# print(usb_6000.read(int(sys.argv[1])))
# print(usb_6000.write(int(sys.argv[1])))

# with nidaqmx.Task() as task:
#     task.do_channels.add_do_chan(
#         'Dev1/port0/line0:3',
#         line_grouping=LineGrouping.CHAN_FOR_ALL_LINES)
    # try:
    #     print('N Lines 1 Sample Boolean Write (Error Expected): ')
    #     print(task.write([True, True, True, True], auto_start=True))
    # except nidaqmx.DaqError as e:
    #     print(e)

    # input('?')

    # print('1 Channel N Lines 1 Sample Unsigned Integer Write: ')
    # print(task.write(2))
    #
    # input('?')
    #
    # print('1 Channel N Lines N Samples Unsigned Integer Write: ')
    # print(task.write([1, 2, 4, 8], auto_start=True))
    # input('?')
