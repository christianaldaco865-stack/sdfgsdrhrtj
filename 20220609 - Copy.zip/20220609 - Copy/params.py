from configparser import RawConfigParser
cfg = RawConfigParser()
fp = open('config.ini', 'r',encoding="utf-8-sig")
cfg.read_file(fp)

#---------------------------------------------------------------- SFIS
url                     = cfg.get('SFIS', 'url')
tsp                     = cfg.get('SFIS', 'TSP')
programID               = 'TSP_PND'
programPassword         = 'g4s15d'
password                = 'pegatron'
deviceID                = cfg.get('SFIS', 'device')
cooling_time            = cfg.getint('SFIS', 'repair_delay_time(s)')

#---------------------------------------------------------------- ErrorCode
Hipot_errorcode	        = cfg.get('ERRORCODE', 'hipot').split(';')
IR_errorcode		        = cfg.get('ERRORCODE', 'ir').split(';')
Resistance_123_errorcode     = cfg.get('ERRORCODE','resistance_1_2_3').split(';')
Resistance_781011_errorcode     = cfg.get('ERRORCODE', 'resistance_7_8_10_11').split(';')
Resistance_9_errorcode     = cfg.get('ERRORCODE', 'resistance_9')
Latch_errorcode             = cfg.get('ERRORCODE', 'latch')

#---------------------------------------------------------------- HIOKI
HIOKI_USB              = cfg.get('KEYSIGHT', 'USB')
HIOKI_timeout          = cfg.getfloat('KEYSIGHT', 'timeout')

#---------------------------------------------------------------- CHROMA
CHROMA_com              = cfg.get('CHROMA', 'comport')
CHROMA_baud             = cfg.getint('CHROMA', 'baudrate')
CHROMA_timeout          = cfg.getfloat('CHROMA', 'timeout')
CHROMA_bytesize         = cfg.getint('CHROMA', 'bytesize')
CHROMA_parity           = cfg.get('CHROMA', 'parity')
CHROMA_stopbits         = cfg.getint('CHROMA', 'stopbits')

#---------------------------------------------------------------- Hipot
Hipot_command  = cfg.get('HIPOT', 'command')

#---------------------------------------------------------------- IR
IR_command  = cfg.get('IR', 'command')

#---------------------------------------------------------------- relay COM define
relay_com_16 = cfg.get('RELAY', 'com_16')
relay_com_8 = cfg.get('RELAY', 'com_8')

#---------------------------------------------------------------- CALIBRATION
cal_thr = cfg.get('CALIBRATION', 'threshold').split(';')

#---------------------------------------------------------------- Threshold
TEST_1 = [float(x) for x in cfg.get('SPEC', 'TEST_1').split(';')]
TEST_2 = [float(x) for x in cfg.get('SPEC', 'TEST_2').split(';')]
TEST_3 = [float(x) for x in cfg.get('SPEC', 'TEST_3').split(';')]
TEST_7 = [float(x) for x in cfg.get('SPEC', 'TEST_7').split(';')]
TEST_8 = [float(x) for x in cfg.get('SPEC', 'TEST_8').split(';')]
TEST_9 = [float(x) for x in cfg.get('SPEC', 'TEST_9').split(';')]
TEST_10 = [float(x) for x in cfg.get('SPEC', 'TEST_10').split(';')]
TEST_11 = [float(x) for x in cfg.get('SPEC', 'TEST_11').split(';')]

latch_negative = cfg.getfloat('SPEC', 'Latch(-12)')
latch_positive = cfg.getfloat('SPEC', 'Latch(+12)')
latch_pulse = cfg.getfloat('SPEC', 'Latch(pulse)')

TEST_4_hipot = [float(x) for x in cfg.get('SPEC', 'TEST_4(Hi-pot)').split(';')]
TEST_5_hipot = [float(x) for x in cfg.get('SPEC', 'TEST_5(Hi-pot)').split(';')]
TEST_6_hipot = [float(x) for x in cfg.get('SPEC', 'TEST_6(Hi-pot)').split(';')]

TEST_4_IR = [float(x) for x in cfg.get('SPEC', 'TEST_4(IR)').split(';')]
TEST_5_IR = [float(x) for x in cfg.get('SPEC', 'TEST_5(IR)').split(';')]
TEST_6_IR = [float(x) for x in cfg.get('SPEC', 'TEST_6(IR)').split(';')]

fp.close()
