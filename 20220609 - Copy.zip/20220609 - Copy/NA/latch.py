import os, time
import threading
import ni
import NA.params as ps
from NA.relay import dr_8 as dr
import visa

os.add_dll_directory('C:\\Program Files (x86)\\Keysight\\IO Libraries Suite\\bin')
DLL = visa.ResourceManager()
myins = DLL.open_resource(ps.HIOKI_USB)
myins.timeout = ps.HIOKI_timeout*1000

def turn_relay(channel):
	dr.setAllStatesOff()
	for i in channel:
		dr.setState(i, True)

class latch_api:
	def __init__(self):
		self.state = False
		self.puls_detect_flag = False
		self.DATA = ''
		self.errorcode_list = ps.Latch_errorcode
		self.errorcode = []

	def initial(self):
		self.state = True
		dr.setAllStatesOff()
		turn_relay([1, 2])
		time.sleep(0.1)
		dr.setAllStatesOff()
		self.res = True
		self.pulse_value = 0
		self.DATA = ''
		self.errorcode.clear()
		time.sleep(0.2)
		self.offset = float(ni.usb_6000.read(5))

	def close(self):
		dr.setAllStatesOff()
		self.state = False
	
	def getCurrent(self):
		v = float(ni.usb_6000.read(5))
		current = (v - self.offset)/0.18
		return current

	def get_pulse_value(self, t):
		self.pulse_value = 0
		print('Start Get Pulse Voltage.')
		while time.time()-t < 0.2:
			tmp_value = ni.usb_6000.read(0)
			if tmp_value > ps.latch_pulse:
				self.pulse_value = tmp_value

		print('close time:', time.time()-t)

	def start(self):
		self.initial()
#--------------------------------------------------------------------- Second Stage
		t = time.time()
		p = threading.Thread(target=lambda :self.get_pulse_value(t))
		p.start()
		turn_relay([3,4])
		
		try:
			p.join()
		except:
			print('pulse FIN!')
		
		current_1 = self.getCurrent()
		dr.setAllStatesOff()
		time.sleep(0.3)
		turn_relay([1,2])
		time.sleep(0.2)
		current_2 = self.getCurrent()
		dr.setAllStatesOff()

		print('Puls Value:', self.pulse_value)
		print('current:', current_1, current_2)

		if self.pulse_value < ps.latch_pulse:
			self.DATA = self.DATA + 'Pulse Voltage, 0, {} V, , {}\n'.format(self.pulse_value, ps.latch_pulse)
			self.res = False
		else:
			self.DATA = self.DATA + 'Pulse Voltage, 1, {} V, , {}\n'.format(self.pulse_value, ps.latch_pulse)

		if current_1 > ps.latch_current[0] or current_2 > ps.latch_current[0]:
			self.res = False
		elif current_1 < ps.latch_current[1] or current_2 < ps.latch_current[1]:
			self.res = False
		self.DATA += 'Current_1, %d, %.5E, %.2f, %.2f\n'%(self.res, current_1, ps.latch_current[0], ps.latch_current[1])
		self.DATA += 'Current_2, %d, %.5E, %.2f, %.2f\n'%(self.res, current_2, ps.latch_current[0], ps.latch_current[1])

		print('pulse Voltage:', self.get_pulse_value)
		print('Current:', current_1, current_2)

		#--------------------------------------------------------------------- Detect lazer
		turn_relay([3,4])
		time.sleep(0.35)
		n_value = float(ni.usb_6000.read(1))
		print('-12V :', n_value)
		
		turn_relay([1,2])
		time.sleep(0.35)
		p_value = ni.usb_6000.read(1)
		print('+12V:', p_value)

		if abs(float(n_value)) > ps.latch_negative:
			self.DATA = self.DATA + 'Latch -12V, 0, {} V, {},\n'.format(n_value, ps.latch_negative)
			self.res = False
		else:
			self.DATA = self.DATA + 'Latch -12V, 1, {} V, {},\n'.format(n_value, ps.latch_negative)

		if abs(float(p_value)) < ps.latch_positive:
			self.DATA = self.DATA + 'Latch +12V, 0, {} V, , {}\n'.format(p_value, ps.latch_positive)
			self.res = False
		else:
			self.DATA = self.DATA + 'Latch +12V, 1, {} V, , {}\n'.format(p_value, ps.latch_positive)

		if not self.res:
			self.errorcode.append(self.errorcode_list)

		self.close()
		return self.errorcode, self.DATA

Latch = latch_api()

if __name__ == '__main__':
	print(Latch.start())
