﻿from datetime import datetime
from tkinter.messagebox import showinfo
import time, os
import threading
from serial import Serial
import NA.params as ps
from NA.relay import *
from check import *
from NA.latch import Latch, myins

def outputLog(DATA, n):
	dir_file_name = os.listdir(os.getcwd())
	if not 'check_log' in dir_file_name:
		os.system('mkdir check_log')

	date, Time = getSFISTime()

	with open('check_log\\%s_%s_%s.csv'%(date, Time.replace(':', ''), n), 'w') as f:
		f.write(DATA)

def judge(item, value, upper=-1, lower=-1):
	result = True
	if upper < 0:
		if float(value) > lower:
			DATA = '{}, {}, {}, , {}\n'.format(item, 1, value, lower)
		else:
			DATA = '{}, {}, {}, , {}\n'.format(item, 0, value, lower)
			result = False
			
	elif lower < 0:
		if upper > float(value):
			DATA = '{}, {}, {}, {}, \n'.format(item, 1, value, upper)
		else:
			DATA = '{}, {}, {}, {}, \n'.format(item, 0, value, upper)
			result = False
	else:
		if upper > float(value) > lower:
			DATA = '{}, {}, {}, {}, {}\n'.format(item, 1, value, upper, lower)
		else:
			DATA = '{}, {}, {}, {}, {}\n'.format(item, 0, value, upper, lower)
			result = False

	return result, DATA

def value_process(data):
	data_list = data.split(',')
	try:
		data_list.remove('')
	except:
		pass
	print(data_list)
	return_value = 0
	for number, i in enumerate(data_list[-2:]):
		return_value += float(i)
	return_value = return_value/(number+1)
	print(return_value)

	return abs(return_value)

class RES_7_8_10_11:
	def __init__(self):
		self.DATA = ''
		self.state = False
		self.result = True
		self.errorcode = []

	def initial(self):
		self.errorcode.clear()
		self.state = True
		self.DATA = ''

		myins.write('*RST')
		myins.write('*CLS')
		myins.write('CONF:CONT')
		myins.write('CONF:RES')
		myins.write('SAMPLE:COUNT 5')

	def close(self):
		reset_all()
		self.state = False

	def start(self):
		ret = True
		res = True
		self.initial()

		#--------------------------------------------------------------------- Test 7
		myins.write('CONF:FRES')
		turn_relay_16([7,8,15,16])
		time.sleep(0.2)
		myins.write('READ?')
		idn = value_process(myins.read().strip())
		res, DATA = judge('TEST 7', idn, upper=ps.TEST_7[0], lower=ps.TEST_7[1])
		self.DATA += DATA
		if not res:
			self.errorcode.append(ps.Resistance_781011_errorcode[0])

		#--------------------------------------------------------------------- Test 8
		myins.write('CONF:RES')
		turn_relay_16([9,10])
		time.sleep(0.2)
		myins.write('READ?')
		idn = myins.read().strip()
		idn = value_process(idn)
		res, DATA = judge('TEST 8', idn, upper=ps.TEST_8[0], lower=ps.TEST_8[1])
		self.DATA += DATA
		if not res:
			turn_relay_16([11, 10])
			time.sleep(0.2)
			myins.write('READ?')
			idn_2 = value_process(myins.read().strip())
			
			res, DATA = judge('TEST 8_1(After 8 fail)', idn, upper=idn_2+2000, lower=idn_2-2000)
			res_2, DATA_2 = judge('TEST 8_1(After 8 fail)', idn, upper=ps.TEST_8[0]+3000, lower=ps.TEST_8[1]-3000)

			if not res:
				self.DATA += 'TEST 9(After 8 fail), 0, {}\n'.format(idn_2)
				self.DATA += DATA
				self.errorcode.append(ps.Resistance_781011_errorcode[1])

			elif not res_2:
				self.DATA += DATA_2
				self.errorcode.append(ps.Resistance_781011_errorcode[1])

			else:
				self.DATA += 'TEST 9(After 8 fail), 1, {}\n'.format(idn_2)
				self.DATA += DATA

		#---------------------------------------------------------------------- Test 10
		turn_relay_16([10,12])
		time.sleep(0.2)
		myins.write('READ?')
		idn = value_process(myins.read().strip())
		res, DATA = judge('TEST 10', idn, upper=ps.TEST_10[0], lower=ps.TEST_10[1])
		self.DATA += DATA
		if not res:
			self.errorcode.append(ps.Resistance_781011_errorcode[2])

		#--------------------------------------------------------------------- Test 11
		turn_relay_16([13,6])
		time.sleep(0.2)
		myins.write('READ?')
		idn = value_process(myins.read().strip())
		res, DATA = judge('TEST 11', idn, upper=ps.TEST_11[0], lower=ps.TEST_11[1])
		self.DATA += DATA
		if not res:
			self.errorcode.append(ps.Resistance_781011_errorcode[3])

		self.close()
		return self.errorcode, self.DATA

class RES_1_2_3:
	def __init__(self):
		self.DATA = ''
		self.state = False
		self.result = True
		self.errorcode = []

	def initial(self):
		self.errorcode.clear()
		self.state = True
		self.DATA = ''

		myins.write('*RST')
		myins.write('*CLS')
		myins.write('CONF:RES')
		myins.write('SAMPLE:COUNT 5')

	def close(self):
		#self.dr.setAllStatesOff()
		self.state = False

	def start(self):
		ret = True
		res = True
		self.initial()

		#--------------------------------------------------------------------- Test 1
		dr_16.setState(1, True)
		dr_16.setState(2, True)
		# turn_relay_16([1,2])
		time.sleep(0.5)
		myins.write('READ?')
		idn = value_process(myins.read().strip())
		res, DATA = judge('TEST 1', idn, upper=ps.TEST_1[0], lower=ps.TEST_1[1])
		self.DATA += DATA
		dr_16.setState(1, False)
		dr_16.setState(2, False)
		if not res:
			self.errorcode.append(ps.Resistance_123_errorcode[0])

		#--------------------------------------------------------------------- Test 2
		dr_16.setState(3, True)
		dr_16.setState(4, True)
		# turn_relay_16([3,4])
		time.sleep(0.5)
		myins.write('READ?')
		idn = value_process(myins.read().strip())
		res, DATA = judge('TEST 2', idn, upper=ps.TEST_2[0], lower=ps.TEST_2[1])
		self.DATA += DATA
		dr_16.setState(3, False)
		dr_16.setState(4, False)
		if not res:
			self.errorcode.append(ps.Resistance_123_errorcode[1])

		#--------------------------------------------------------------------- Test 3
		dr_16.setState(5, True)
		dr_16.setState(6, True)
		# turn_relay_16([5,6])
		time.sleep(0.5)
		myins.write('READ?')
		idn = value_process(myins.read().strip())
		res, DATA = judge('TEST 3', idn, upper=ps.TEST_3[0], lower=ps.TEST_3[1])
		self.DATA += DATA
		dr_16.setState(5, False)
		dr_16.setState(6, False)
		if not res:
			self.errorcode.append(ps.Resistance_123_errorcode[2])

		self.close()

		return self.errorcode, self.DATA

class RES_9:
	def __init__(self):
		self.DATA = ''
		self.state_0 = False
		self.state_1 = False
		self.result = True
		self.errorcode = []
		
	def initial(self):
		self.errorcode.clear()
		self.DATA = ''
		self.state_1 = True
		myins.write('*RST')
		myins.write('*CLS')
		myins.write('CONF:RES')
		myins.write('SAMPLE:COUNT 2')
		
	def close(self):
		reset_all()
		self.state_1 = False

	def start(self):
		self.start_0()
		self.start_1()

		return self.errorcode, self.DATA

	def start_0(self):
		self.state_0 = True
		self.initial()
		turn_relay_16([11, 10])
		time.sleep(0.2)
		myins.write('READ?')
		idn = value_process(myins.read().strip())
		res, self.DATA = judge('TEST 9(before heating)', idn, upper=ps.TEST_9_bef[0], lower=ps.TEST_9_bef[1])
		if not res:
			self.errorcode.append(ps.Resistance_9_errorcode)
		reset_all()
		time.sleep(0.1)
		turn_relay_16([14])

		self.timer = time.time()
		self.state_1 = True
		self.state_0 = False

	def start_1(self):
		

		while time.time() - self.timer < 31.0:
			time.sleep(0.02)

		turn_relay_16([11, 10])
		time.sleep(0.2)
		myins.write('READ?')
		idn = value_process(myins.read().strip())
		res, DATA = judge('TEST 9', idn, upper=ps.TEST_9[0], lower=ps.TEST_9[1])
		self.DATA += DATA
		if not res:
			self.errorcode.append(ps.Resistance_9_errorcode)

		self.close()

		return self.errorcode, self.DATA

class serialFunction:
	def __init__(self, command, errorcode, com, baud, time, bytesize=8, parity='N', stopbits=1, FILE=''):
		self.comport = Serial(com, baud, timeout=5, bytesize=bytesize, parity=parity, stopbits=stopbits)
		print(self.comport)
		self.command_file = command
		self.comport.close()
		self.DATA = ''
		self.state = False
		self.errorcode_list = errorcode
		self.errorcode = []

	def initial(self):
		self.errorcode.clear()
		self.state = True
		self.comport.open()

	def start(self):
		self.initial()
		DATA = ''
		process_list = []
		func_dict = {"write":self.devicewrite,"read":self.deviceread,"sleep":self.devicesleep,"check":self.devicecheck}

		#------------------------------------------## 讀取指令列
		with open(self.command_file) as f:
			for command in f:
				command = command.split(";")
				command = [i.strip() for i in command]
				process_list.append(command)

		#------------------------------------------## 依序執行指令並記錄結果回傳(result, SFIS Data)給 UI
		# process = [動作, 動作對應的參數一(pass, Limit), 動作對應的參數二(上下限)]
		# Ex: read --> (limit/下限/上限, pass(不處理)), (上傳項目名稱)
		for i, process in enumerate(process_list):
			time.sleep(0.2)
			result, returnValue = func_dict[process[0]](process[1])
			if result == -1:
				showinfo('Error', returnValue)
				self.comport.close()
				self.DATA = DATA
				return 'Error', ''

			#------------------------------------------------ If pass 則跳過繼續下一動作
			if process[0] == 'read':
				if 4 > process[1].find('pass') > -1:
					continue
				#------------ DATA合併: 項目名稱, 測試結果(1 or 0), 測試值
				DATA += '{}, {}, %.3E, '.format(process[2], result)%(float(returnValue))

				#--------------------- 塞入spec
				spec = process[1].split('/')[1:][::-1]
				print(spec)
				for a in spec:
					try:
						DATA += '%.3E, '%(float(a))
					except:
						DATA += '{}, '.format(a)
				DATA += '\n'

			if not result:
				print('{}, {} Fail!'.format(i, process[1]))
				self.errorcode.append(self.errorcode_list[len(DATA.split('\n'))-2])

		self.comport.close()
		self.DATA = DATA
		return self.errorcode, self.DATA

	# 回傳測試結果(1,0,-1), 測試值 --> 1:pass , 0:fail, -1:error
	# 如果有意外狀況,回傳 -1, Error message
	def deviceread(self, command):
		value = self.comport.readline().decode().strip()
		if value == '':
			print('Device Data timeout...')
			return -1, 'Device Data timeout...'
		try:
			command = command.split('/')
			print(command)
			if command[0] == "result":
				print('r value: {}'.format(value))
				if value != command[1]:
					return 0, value
			elif command[0] == "limit":
				if command[1] != '':
					if not float(command[1]) <= float(value):
						return 0, value
				if command[2] != '':
					if not float(value) <= float(command[2]):
						return 0, value
				# if not float(command[1]) <= float(value) <= float(command[2]):
				# 	return 0, value
			elif command[0] == "pass":
				return 1, value
		except:
			message = traceback.format_exc()
			print(message)
			return -1, message
		return 1, value

	def devicesleep(self, command):
		time.sleep(float(command))
		return 1, None

	def devicewrite(self, command):
		try:
			if self.comport.writable:
				command += '\n'
				self.comport.write(command.encode())
			else:
				return -1, 'Comport not writable!'

			return 1, command[:-2]

		except:
			return -1, traceback.format_exc()

	def devicecheck(self, command):
		command = command.split('/')
		for i in range(5):
			ret, value = self.devicewrite(command[0])
			if ret == -1:
				return -1, message
			value = self.comport.readline().decode().strip()
			print('check value:', value)
	
			if value==command[1]:
				return 1, None
			else:
				self.devicewrite(command[2])

		return -1, "Check device setting Fail!"

class hipot:
	def __init__(self):
		self.com = Serial(ps.CHROMA_com, ps.CHROMA_baud, timeout=ps.CHROMA_timeout)
		self.com.close()
	
	def check(self, expt, command, flag=False):
		self.com.write('{} {}\n'.format(command, expt).encode())
		time.sleep(0.5)
		self.com.write('{}?\n'.format(command).encode())
		value = self.com.readline().decode().strip()
		if flag:
			value = float(value)
			expt = float(expt)
			
		print(value, expt)
		if value != expt:
			self.com.write('{} {}\n'.format(command, expt).encode())
			time.sleep(0.3)
			self.com.write('{}?\n'.format(command).encode())
			value = self.com.readline().decode().strip()
			if value != expt:
				print('Device setting Error!')
				print('expect:{} output:{}'.format(expt, value))
				self.log = value
				return False
		return True
		
	def initial(self):
		self.DATA = ''
		self.errorcode = []
		self.log = ''
		self.com.open()
		self.com.write(b'*CLS\n')
		time.sleep(1)
		self.com.write(b':SOUR:SAFE:SNUM?\n')
		time.sleep(1)
		step_num = self.com.readline()
		print(step_num)
		step_num = int(step_num.decode().strip())

		for i in range(1, step_num):
			command = ':SOUR:SAFE:STEP {}:DEL\n'.format(step_num - i + 1)
			self.com.write(command.encode())
			time.sleep(0.3)
		print('Success initial Chroma...')

		if not self.check('4300', 'SOUR:SAFE:STEP 1:DC:LEV', flag=True):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		if not self.check('1', 'SOUR:SAFE:STEP 1:DC:TIME:RAMP', flag=True):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		if not self.check('1', 'SOUR:SAFE:STEP 1:DC:TIME:TEST', flag=True):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		# if not self.check('0.00001', 'SOUR:SAFE:STEP 1:DC:LIM:HIGH'):
		# 	self.errorcode.append('IP10B8')
		# 	self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
		# 	return self.errorcode, self.DATA

	def getReturnValue(self):
		loop_time = time.time()
		while time.time()-loop_time < 5:
			self.com.write(b'SOUR:SAFE:RES:STEP 1:JUDG?\n')
			judge = self.com.readline().decode().strip()
			if judge.find('115') < 0:
				flag = True
				break
			time.sleep(0.5)
		
		self.com.write(b'SOUR:SAFE:RES:STEP 1:MMET?\n')
		value = float(self.com.readline().decode().strip())

		return judge, value


	def close(self):
		self.com.close()

	def start(self):
		self.initial()

		#---------------------------------------   High-CH=2 , Low-CH=1
		if not self.check('(@(2))', 'SOUR:SAFE:STEP 1:DC:CHAN:HIGH'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		if not self.check('(@(1))', 'SOUR:SAFE:STEP 1:DC:CHAN:LOW'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		
		self.com.write(b'SOUR:SAFE:STAR\n')
		time.sleep(3)
		judge, value = self.getReturnValue()
		print(judge, value)
		
		if judge != '116':
			self.errorcode.append(ps.Hipot_errorcode[0])
			self.DATA += 'Test4(Hipot) Judge Value, 0, %s, 116, 116,\n'%(judge)
		elif ps.TEST_4_hipot[0] < value or ps.TEST_4_hipot[1] > value:
			self.errorcode.append(ps.Hipot_errorcode[0])
			self.DATA += 'Test4(Hipot), 0, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_4_hipot[0], ps.TEST_4_hipot[1])
		else:
			self.DATA += 'Test4(Hipot), 1, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_4_hipot[0], ps.TEST_4_hipot[1])

		#---------------------------------------   High-CH=1 , Low-CH=3
		if not self.check('(@(1))', 'SOUR:SAFE:STEP 1:DC:CHAN:HIGH'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		if not self.check('(@(3))', 'SOUR:SAFE:STEP 1:DC:CHAN:LOW'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		
		self.com.write(b'SOUR:SAFE:STAR\n')
		time.sleep(3)
		judge, value = self.getReturnValue()
		print(judge, value)
		
		if judge != '116':
			self.errorcode.append(ps.Hipot_errorcode[1])
			self.DATA += 'Test5(Hipot) Judge Value, 0, %s, 116, 116,\n'%(judge)
		elif ps.TEST_5_hipot[0] < value or ps.TEST_5_hipot[1] > value:
			self.errorcode.append(ps.Hipot_errorcode[1])
			self.DATA += 'Test5(Hipot), 0, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_5_hipot[0], ps.TEST_5_hipot[1])
		else:
			self.DATA += 'Test5(Hipot), 1, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_5_hipot[0], ps.TEST_5_hipot[1])

		#---------------------------------------   High-CH=2 , Low-CH=3
		if not self.check('(@(2))', 'SOUR:SAFE:STEP 1:DC:CHAN:HIGH'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		if not self.check('(@(3))', 'SOUR:SAFE:STEP 1:DC:CHAN:LOW'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		
		self.com.write(b'SOUR:SAFE:STAR\n')
		time.sleep(3)
		judge, value = self.getReturnValue()
		print(judge, value)
		
		if judge != '116':
			self.errorcode.append(ps.Hipot_errorcode[2])
			self.DATA += 'Test6(Hipot) Judge Value, 0, %s, 116, 116,\n'%(judge)
		elif ps.TEST_6_hipot[0] < value or ps.TEST_6_hipot[1] > value:
			self.errorcode.append(ps.Hipot_errorcode[2])
			self.DATA += 'Test6(Hipot), 0, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_6_hipot[0], ps.TEST_6_hipot[1])
		else:
			self.DATA += 'Test6(Hipot), 1, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_6_hipot[0], ps.TEST_6_hipot[1])

		self.close()
		return self.errorcode, self.DATA

class ir:
	def __init__(self):
		self.com = Serial(ps.CHROMA_com, ps.CHROMA_baud, timeout=ps.CHROMA_timeout)
		self.com.close()
	
	def check(self, expt, command, flag=False):
		self.com.write('{} {}\n'.format(command, expt).encode())
		time.sleep(0.5)
		self.com.write('{}?\n'.format(command).encode())
		value = self.com.readline().decode().strip()
		if flag:
			value = float(value)
			expt = float(expt)
			
		print(value, expt)
		if value != expt:
			self.com.write('{} {}\n'.format(command, expt).encode())
			time.sleep(0.3)
			self.com.write('{}?\n'.format(command).encode())
			value = self.com.readline().decode().strip()
			if value != expt:
				print('Device setting Error!')
				print('expect:{} output:{}'.format(expt, value))
				self.log = value
				return False
		return True
		
	def initial(self):
		self.DATA = ''
		self.errorcode = []
		self.log = ''
		self.com.open()
		self.com.write(b'*CLS\n')
		time.sleep(1)
		self.com.write(b':SOUR:SAFE:SNUM?\n')
		time.sleep(1)
		step_num = self.com.readline()
		print(step_num)
		step_num = int(step_num.decode().strip())

		for i in range(1, step_num):
			command = ':SOUR:SAFE:STEP {}:DEL\n'.format(step_num - i + 1)
			self.com.write(command.encode())
			time.sleep(0.3)
		print('Success initial Chroma...')

		if not self.check('500', 'SOUR:SAFE:STEP 1:IR:LEV', flag=True):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA

		if not self.check('1000000000', 'SOUR:SAFE:STEP 1:IR:LIM:LOW', flag=True):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA

		if not self.check('1', 'SOUR:SAFE:STEP 1:IR:TIME:TEST', flag=True):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA

	def getReturnValue(self):
		loop_time = time.time()
		while time.time()-loop_time < 5:
			self.com.write(b'SOUR:SAFE:RES:STEP 1:JUDG?\n')
			judge = self.com.readline().decode().strip()
			if judge.find('115') < 0:
				break
			time.sleep(0.5)
		
		self.com.write(b'SOUR:SAFE:RES:STEP 1:MMET?\n')
		value = float(self.com.readline().decode().strip())

		return judge, value

	def close(self):
		self.com.close()

	def start(self):
		self.initial()
		if self.errorcode != []:
			return self.errorcode, self.DATA

		#---------------------------------------   High-CH=2 , Low-CH=1
		if not self.check('(@(2))', 'SOUR:SAFE:STEP 1:IR:CHAN:HIGH'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		if not self.check('(@(1))', 'SOUR:SAFE:STEP 1:IR:CHAN:LOW'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		
		self.com.write(b'SOUR:SAFE:STAR\n')
		time.sleep(1.5)
		judge, value = self.getReturnValue()
		print(judge, value)

		if judge != '116':
			self.errorcode.append(ps.IR_errorcode[0])
			self.DATA += 'Test4(IR) Judge Value, 0, %s, 116, 116,\n'%(judge)
		elif ps.TEST_4_IR[0] < value or ps.TEST_4_IR[1] > value:
			self.errorcode.append(ps.IR_errorcode[0])
			self.DATA += 'Test4(IR), 0, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_4_IR[0], ps.TEST_4_IR[1])
		else:
			self.DATA += 'Test4(IR), 1, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_4_IR[0], ps.TEST_4_IR[1])

		#---------------------------------------   High-CH=1 , Low-CH=3
		if not self.check('(@(1))', 'SOUR:SAFE:STEP 1:IR:CHAN:HIGH'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		if not self.check('(@(3))', 'SOUR:SAFE:STEP 1:IR:CHAN:LOW'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		
		self.com.write(b'SOUR:SAFE:STAR\n')
		time.sleep(1.5)
		judge, value = self.getReturnValue()
		print(judge, value)

		if judge != '116':
			self.errorcode.append(ps.IR_errorcode[1])
			self.DATA += 'Test5(IR) Judge Value, 0, %s, 116, 116,\n'%(judge)
		elif ps.TEST_5_IR[0] < value or ps.TEST_5_IR[1] > value:
			self.errorcode.append(ps.IR_errorcode[1])
			self.DATA += 'Test5(IR), 0, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_5_IR[0], ps.TEST_5_IR[1])
		else:
			self.DATA += 'Test5(IR), 1, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_5_IR[0], ps.TEST_5_IR[1])

		#---------------------------------------   High-CH=2 , Low-CH=3
		if not self.check('(@(2))', 'SOUR:SAFE:STEP 1:IR:CHAN:HIGH'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		if not self.check('(@(3))', 'SOUR:SAFE:STEP 1:IR:CHAN:LOW'):
			self.errorcode.append('IP10B8')
			self.DATA += 'Chroma Setting Error, 0, %s\n'%(self.log)
			return self.errorcode, self.DATA
		
		self.com.write(b'SOUR:SAFE:STAR\n')
		time.sleep(1.5)
		judge, value = self.getReturnValue()
		print(judge, value)

		if judge != '116':
			self.errorcode.append(ps.IR_errorcode[2])
			self.DATA += 'Test6(IR) Judge Value, 0, %s, 116, 116,\n'%(judge)
		elif ps.TEST_6_IR[0] < value or ps.TEST_6_IR[1] > value:
			self.errorcode.append(ps.IR_errorcode[2])
			self.DATA += 'Test6(IR), 0, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_6_IR[0], ps.TEST_6_IR[1])
		else:
			self.DATA += 'Test6(IR), 1, %.3E, %.3E, %.3E,\n'%(value, ps.TEST_6_IR[0], ps.TEST_6_IR[1])

		self.close()
		return self.errorcode, self.DATA

def testProcess(UI, flag=True):
	if flag:
		message = 'Please press button to start Test!\n請按下按鈕開始測試'	
	else:
		message = 'Please put Golden Sample and press button to start Test!\n請放置正常樣本並按下按鈕開始測試'
	showinfo('message', message)

	#---------------------------------------------- PreTest
	e, d = preTest_func.start()
	if e != []:
		UI.DATA_2_list(d)
		return 'FAIL', ''

	#---------------------------------------------- IR
	errorcode, DATA = IR_func.start()
	UI.DATA_2_list(DATA)
	if errorcode != []:
		return errorcode[0], DATA

	#---------------------------------------------- Resistance 7,8,10,11
	errorcode, subDATA = Resistance_7_8_10_11.start()
	DATA += subDATA
	UI.DATA_2_list(subDATA)
	if errorcode != []:
		return errorcode[0], DATA

	#---------------------------------------------- Latch
	Latch.start()
	DATA += Latch.DATA
	UI.DATA_2_list(Latch.DATA)
	errorcode += Latch.errorcode
	if errorcode != []:
		return errorcode[0], DATA

	#---------------------------------------------- Resistance 9
	Resistance_9.start_0()

	#---------------------------------------------- Hi-pot
	sbuErrorcode, subDATA = Hipot_func.start()
	DATA += subDATA
	UI.DATA_2_list(subDATA)
	errorcode += Hipot_func.errorcode

	#---------------------------------------------- Resistance 1,2,3 & Latch
	# p1 = threading.Thread(target=Latch.start).start()
	# Resistance_1_2_3.start()
	# DATA += Resistance_1_2_3.DATA
	# UI.DATA_2_list(Resistance_1_2_3.DATA)
	# errorcode += Resistance_1_2_3.errorcode
	
	# while Latch.state:
	# 	time.sleep(0.2)

	# DATA += Latch.DATA
	# UI.DATA_2_list(Latch.DATA)
	# errorcode += Latch.errorcode
	Resistance_1_2_3.start()
	DATA += Resistance_1_2_3.DATA
	UI.DATA_2_list(Resistance_1_2_3.DATA)
	errorcode += Resistance_1_2_3.errorcode
	
	#---------------------------------------------- Resistance 9 get value
	Resistance_9.start_1()
	DATA += Resistance_9.DATA
	UI.DATA_2_list(Resistance_9.DATA)

	errorcode += Resistance_9.errorcode

	turn_relay_8([7,8])
	time.sleep(0.3)
	reset_all()

	print(errorcode)

	if errorcode != []:
		return errorcode[0], DATA
	elif flag:
		return '', DATA
	
	outputLog(DATA, 'pass')

	message = 'Please put Error Sample and press button to start Test!\n請放置異常樣本並按下按鈕開始測試'
	showinfo('message', message)
	for i in UI.tree.tree.get_children():
		UI.tree.tree.delete(i)

	#---------------------------------------------- PreTest
	e, d = preTest_func.start()
	if e != []:
		UI.DATA_2_list(d)
		return 'FAIL', ''
	
	#---------------------------------------------- IR
	errorcode, errorDATA = IR_func.start()
	UI.DATA_2_list(errorDATA)
	
	#---------------------------------------------- Resistance 7,8,10,11
	subErrorcode, subDATA = Resistance_7_8_10_11.start()
	errorcode += subErrorcode
	errorDATA += subDATA
	UI.DATA_2_list(subDATA)

	#---------------------------------------------- Resistance 9
	Resistance_9.start_0()

	#---------------------------------------------- Hi-pot
	subErrorcode, subDATA = Hipot_func.start()
	errorcode += subErrorcode
	errorDATA += subDATA
	UI.DATA_2_list(subDATA)

	#---------------------------------------------- Resistance 1,2,3 & Latch
	p1 = threading.Thread(target=Latch.start).start()
	Resistance_1_2_3.start()
	errorDATA += Resistance_1_2_3.DATA
	UI.DATA_2_list(Resistance_1_2_3.DATA)
	errorcode += Resistance_1_2_3.errorcode
	
	while Latch.state:
		time.sleep(0.2)

	errorDATA += Latch.DATA
	UI.DATA_2_list(Latch.DATA)
	errorcode += Latch.errorcode
	
	#---------------------------------------------- Resistance 9 get value
	Resistance_9.start_1()
	errorDATA += Resistance_9.DATA
	UI.DATA_2_list(Resistance_9.DATA)

	errorcode += Resistance_9.errorcode

	turn_relay_8([7,8])
	time.sleep(0.3)
	reset_all()
	
	DATA += errorDATA


	print(errorcode)
	if len(errorcode) == 15:
		outputLog(errorDATA, 'fail')
		return '', errorDATA

	return 'False', DATA

Resistance_7_8_10_11 = RES_7_8_10_11()
Resistance_1_2_3 = RES_1_2_3()
Resistance_9 = RES_9()

preTest_func = serialFunction('preTest.ini', ['FAIL'], ps.CHROMA_com,
ps.CHROMA_baud, ps.CHROMA_timeout, bytesize=ps.CHROMA_bytesize,
parity=ps.CHROMA_parity)

Hipot_func = hipot()
IR_func = ir()

# IR_func = serialFunction('IR.ini', ps.IR_errorcode, ps.CHROMA_com,
# ps.CHROMA_baud, ps.CHROMA_timeout, bytesize=ps.CHROMA_bytesize,
# parity=ps.CHROMA_parity)

# Hipot_func = serialFunction('Hipot.ini', ps.Hipot_errorcode, ps.CHROMA_com,
# ps.CHROMA_baud, ps.CHROMA_timeout, bytesize=ps.CHROMA_bytesize,
# parity=ps.CHROMA_parity)