﻿import params as ps
import os, sys, time
import visa
import threading
from tkinter import END
import datetime
import relay
from serial import Serial
import traceback
from tkinter.messagebox import showinfo


root = 'C:\\Program Files (x86)\\IVI Foundation\\VISA\\WinNT\\agvisa\\agbin\\visa32.dll'
os.add_dll_directory('C:\\Program Files (x86)\\Keysight\\IO Libraries Suite\\bin')
DLL = visa.ResourceManager()
myins = DLL.open_resource(ps.HIOKI_USB)
myins.timeout = ps.HIOKI_timeout*1000
myins.write('CONF:RES')



def outputLog(DATA, n):
	dir_file_name = os.listdir(os.getcwd())
	if not 'check_log' in dir_file_name:
		os.system('mkdir check_log')

	date, Time = getSFISTime()

	with open('check_log\\%s_%s.csv'%(date, n), 'w') as f:
		f.write(DATA)


class RES_7_8_10_11:
	def __init__(self, myinst, dr):
		self.myinst = myinst
		self.DATA = ''
		self.state = False
		self.result = True
		self.errorcode = ''
		self.dr = dr

	def turn_relay(self, channel):
		self.dr.setAllStatesOff()
		for i in channel:
			self.dr.setState(i, True)

	def judge(self, item, value, upper=-1, lower=-1 ,flag=True):
		if upper < 0:
			if float(value) > lower:
				self.DATA = self.DATA + '{}, {}, {}, , {}\n'.format(item, 1, value, lower)
			else:
				self.DATA = self.DATA + '{}, {}, {}, , {}\n'.format(item, 0, value, lower)
				self.result = False
				if flag:
					showinfo('message', '{} FAIL!'.format(item))
				return True, False
		elif lower < 0:
			if upper > float(value):
				self.DATA = self.DATA + '{}, {}, {}, {}, \n'.format(item, 1, value, upper)
			else:
				self.DATA = self.DATA + '{}, {}, {}, {}, \n'.format(item, 0, value, upper)
				self.result = False
				if flag:
					showinfo('message', '{} FAIL!'.format(item))
				return True, False
		else:
			if upper > float(value) > lower:
				self.DATA = self.DATA + '{}, {}, {}, {}, {}\n'.format(item, 1, value, upper, lower)
			else:
				self.DATA = self.DATA + '{}, {}, {}, {}, {}\n'.format(item, 0, value, upper, lower)
				self.result = False
				if flag:
					showinfo('message', '{} FAIL!'.format(item))
				return True, False

		return True, True

	def value_process(self, data):
		# m.output_message(str(data)+'\n')

		data_list = data.split(',')
		try:
			data_list.remove('')
		except:
			pass
		print(data_list)
		return_value = 0
		for number, i in enumerate(data_list[-2:]):
			return_value += float(i)
		return_value = return_value/(number+1)
		print(return_value)

		return return_value

	def initial(self):
		self.errorcode = ''
		self.state = True
		self.DATA = ''

		myins.write('*RST')
		myins.write('*CLS')
		myins.write('CONF:CONT')
		myins.write('CONF:RES')
		myins.write('SAMPLE:COUNT 5')

	def close(self):
		self.dr.setAllStatesOff()
		self.state = False

	def start(self):
		ret = True
		res = True
		self.initial()

#--------------------------------------------------------------------- Test 7
		myins.write('CONF:FRES')
		myins.write('SAMPLE:COUNT 5')
		self.turn_relay([7,8,15,16])
		time.sleep(0.2)
		self.myinst.write('READ?')
		idn = self.myinst.read().strip()
		print('value1:', idn)
		idn = self.value_process(idn)
		print('value2:', idn)
		ret, res = self.judge('TEST 7', idn, upper=ps.TEST_7[0], lower=ps.TEST_7[1])
		if not res:
			self.errorcode = ps.Resistance_781011_errorcode[0]
			self.close()
			return self.errorcode, self.DATA

#--------------------------------------------------------------------- Test 8
		myins.write('CONF:RES')
		myins.write('SAMPLE:COUNT 5')
		self.turn_relay([9,10])
		time.sleep(0.2)
		self.myinst.write('READ?')
		idn = self.myinst.read().strip()
		idn = self.value_process(idn)
		ret, res = self.judge('TEST 8', idn, upper=ps.TEST_8[0], lower=ps.TEST_8[1], flag=False)
		if not res:
			self.turn_relay([11, 10])
			time.sleep(0.2)
			self.myinst.write('READ?')
			idn_2 = self.myinst.read().strip()
			idn_2 = self.value_process(idn_2)
			self.DATA += 'TEST 9(After 8 fail), 1, {}\n'.format(idn_2)
			ret, res = self.judge('TEST 8_1(After 8 fail)', idn, upper=idn_2+2000, lower=idn_2-2000)

			if not res:
				self.errorcode = ps.Resistance_781011_errorcode[1]
				self.close()
				return self.errorcode, self.DATA

#---------------------------------------------------------------------- Test 10
		self.turn_relay([10,12])
		time.sleep(0.2)
		self.myinst.write('READ?')
		idn = self.myinst.read().strip()
		idn = self.value_process(idn)
		ret, res = self.judge('TEST 10', idn, upper=ps.TEST_10[0], lower=ps.TEST_10[1])
		if not res:
			self.errorcode = ps.Resistance_781011_errorcode[2]
			self.close()
			return self.errorcode, self.DATA

#--------------------------------------------------------------------- Test 11
		self.turn_relay([13,6])
		time.sleep(0.2)
		self.myinst.write('READ?')
		idn = self.myinst.read().strip()
		idn = self.value_process(idn)
		ret, res = self.judge('TEST 11', idn, upper=ps.TEST_11[0], lower=ps.TEST_11[1])
		if not res:
			self.errorcode = ps.Resistance_781011_errorcode[3]

		self.close()
		return self.errorcode, self.DATA

class RES_1_2_3:
	def __init__(self, myinst, dr):
		self.myinst = myinst
		self.DATA = ''
		self.state = False
		self.result = True
		self.errorcode = ''
		self.dr = dr

	def turn_relay(self, channel, flag):
		for i in channel:
			self.dr.setState(i, flag)

	def judge(self, item, value, upper=-1, lower=-1):
		if upper < 0:
			if float(value) > lower:
				self.DATA = self.DATA + '{}, {}, {}, , {}\n'.format(item, 1, value, lower)
			else:
				self.DATA = self.DATA + '{}, {}, {}, , {}\n'.format(item, 0, value, lower)
				self.result = False
				showinfo('message', '{} FAIL!'.format(item))
				return True, False
		elif lower < 0:
			if upper > float(value):
				self.DATA = self.DATA + '{}, {}, {}, {}, \n'.format(item, 1, value, upper)
			else:
				self.DATA = self.DATA + '{}, {}, {}, {}, \n'.format(item, 0, value, upper)
				self.result = False
				showinfo('message', '{} FAIL!'.format(item))
				return True, False
		else:
			if upper > float(value) > lower:
				self.DATA = self.DATA + '{}, {}, {}, {}, {}\n'.format(item, 1, value, upper, lower)
			else:
				self.DATA = self.DATA + '{}, {}, {}, {}, {}\n'.format(item, 0, value, upper, lower)
				self.result = False
				showinfo('message', '{} FAIL!'.format(item))
				return True, False

		return True, True

	def value_process(self, data):
		# m.output_message(str(data)+'\n')
		data_list = data.split(',')
		try:
			data_list.remove('')
		except:
			pass
		print(data_list)
		return_value = 0
		for number, i in enumerate(data_list):
			return_value += float(i)
		return_value = return_value/(number+1)
		print(return_value)

		return return_value

	def initial(self):
		self.errorcode = ''
		self.state = True
		self.DATA = ''

		myins.write('*RST')
		myins.write('*CLS')
		myins.write('CONF:RES')
		myins.write('SAMPLE:COUNT 5')

	def close(self):
		#self.dr.setAllStatesOff()
		self.state = False

	def start(self):
		ret = True
		res = True
		self.initial()

#--------------------------------------------------------------------- Test 1
		self.turn_relay([1,2], True)
		time.sleep(0.5)
		self.myinst.write('READ?')
		idn = self.myinst.read().strip()
		idn = self.value_process(idn)
		self.turn_relay([1,2], False)
		ret, res = self.judge('TEST 1', idn, upper=ps.TEST_1[0], lower=ps.TEST_1[1])
		if not res:
			self.errorcode = ps.Resistance_123_errorcode[0]
			self.close()
			return self.errorcode, self.DATA

#--------------------------------------------------------------------- Test 2
		self.turn_relay([3,4], True)
		time.sleep(0.5)
		self.myinst.write('READ?')
		idn = self.myinst.read().strip()
		idn = self.value_process(idn)
		self.turn_relay([3,4], False)
		ret, res = self.judge('TEST 2', idn, upper=ps.TEST_2[0], lower=ps.TEST_2[1])
		if not res:
			self.errorcode = ps.Resistance_123_errorcode[1]
			self.close()
			return self.errorcode, self.DATA

#--------------------------------------------------------------------- Test 3
		self.turn_relay([5,6], True)
		time.sleep(0.5)
		self.myinst.write('READ?')
		idn = self.myinst.read().strip()
		idn = self.value_process(idn)
		self.turn_relay([5,6], False)
		ret, res = self.judge('TEST 3', idn, upper=ps.TEST_3[0], lower=ps.TEST_3[1])
		if not res:
			self.errorcode = ps.Resistance_123_errorcode[2]

		self.close()

		return self.errorcode, self.DATA

class RES_9:
	def __init__(self, myinst, dr):
		self.myinst = myinst
		self.DATA = ''
		self.state_0 = False
		self.state_1 = False
		self.result = True
		self.errorcode = ''
		self.dr = dr
		self.timer = 0

	def turn_relay(self, channel, flag):
		for i in channel:
			self.dr.setState(i, flag)

	def judge(self, item, value, upper=-1, lower=-1):
		if upper < 0:
			if float(value) > lower:
				self.DATA = self.DATA + '{}, {}, {}, , {}\n'.format(item, 1, value, lower)
			else:
				self.DATA = self.DATA + '{}, {}, {}, , {}\n'.format(item, 0, value, lower)
				self.result = False
				showinfo('message', '{} FAIL!'.format(item))
				self.errorcode = ps.Resistance_9_errorcode
				return True, False
		elif lower < 0:
			if upper > float(value):
				self.DATA = self.DATA + '{}, {}, {}, {}, \n'.format(item, 1, value, upper)
			else:
				self.DATA = self.DATA + '{}, {}, {}, {}, \n'.format(item, 0, value, upper)
				self.result = False
				showinfo('message', '{} FAIL!'.format(item))
				self.errorcode = ps.Resistance_9_errorcode
				return True, False
		else:
			if upper > float(value) > lower:
				self.DATA = self.DATA + '{}, {}, {}, {}, {}\n'.format(item, 1, value, upper, lower)
			else:
				self.DATA = self.DATA + '{}, {}, {}, {}, {}\n'.format(item, 0, value, upper, lower)
				self.result = False
				showinfo('message', '{} FAIL!'.format(item))
				self.errorcode = ps.Resistance_9_errorcode
				return True, False

		return True, True

	def value_process(self, data):
		data_list = data.split(',')
		try:
			data_list.remove('')
		except:
			pass
		return_value = 0
		for number, i in enumerate(data_list):
			return_value += float(i)
		return_value = return_value/(number+1)

		return return_value

	def initial(self):
		self.errorcode = ''
		self.DATA = ''
		self.state_1 = True
		myins.write('*RST')
		myins.write('*CLS')
		myins.write('CONF:RES')
		myins.write('SAMPLE:COUNT 2')

	def close(self):
		self.dr.setAllStatesOff()
		self.state_1 = False

	def start(self):
		self.start_0()
		self.start_1()

		return self.errorcode, self.DATA

	def start_0(self):
		self.state_0 = True
		self.turn_relay([14], True)
		self.timer = time.time()
		self.state_1 = True
		self.state_0 = False

	def start_1(self):
		self.initial()

		while time.time() - self.timer < 30.0:
			time.sleep(0.02)
		self.turn_relay([14], False)
		self.turn_relay([11, 10], True)
		time.sleep(0.2)
		self.myinst.write('READ?')
		idn = self.myinst.read().strip()
		idn = self.value_process(idn)
		self.turn_relay([11, 10], False)
		ret, res = self.judge('TEST 9', idn, upper=ps.TEST_9[0], lower=ps.TEST_9[1])

		self.close()

		return self.errorcode, self.DATA

class serialFunction:
	def __init__(self, command, errorcode, com, baud, time, bytesize=8, parity='N', stopbits=1, FILE=''):
		self.comport = Serial(com, baud, timeout=5, bytesize=bytesize, parity=parity, stopbits=stopbits)
		print(self.comport)
		self.command_file = command
		self.comport.close()
		self.DATA = ''
		self.state = False
		self.errorcode_list = errorcode
		self.errorcode = ''

	def start(self):
		self.errorcode = ''
		self.state = True
		self.comport.open()
		DATA = ''
		process_list = []
		func_dict = {"write":self.devicewrite,"read":self.deviceread,"sleep":self.devicesleep,"check":self.devicecheck}

#------------------------------------------## 讀取指令列
		with open(self.command_file) as f:
			for command in f:
				command = command.split(";")
				command = [i.strip() for i in command]
				process_list.append(command)

#------------------------------------------## 依序執行指令並記錄結果回傳(result, SFIS Data)給 UI
# process = [動作, 動作對應的參數一(pass, Limit), 動作對應的參數二(上下限)]
# Ex: read --> (limit/下限/上限, pass(不處理)), (上傳項目名稱)
		for i, process in enumerate(process_list):
			# print(process)
			time.sleep(0.2)
			result, returnValue = func_dict[process[0]](process[1])
			if result == -1:
				showinfo('Error', returnValue)
				self.comport.close()
				self.DATA = DATA
				return 'Error', ''

			#------------------------------------------------ If pass 則跳過繼續下一動作
			if process[0] == 'read':
				if 4 > process[1].find('pass') > -1:
					continue
				#------------ DATA合併: 項目名稱, 測試結果(1 or 0), 測試值
				print(type(returnValue), returnValue)
				DATA += '{}, {}, %.3E, '.format(process[2], result)%(float(returnValue))

				#--------------------- 塞入spec
				spec = process[1].split('/')[1:][::-1]
				print(spec)
				for a in spec:
					try:
						DATA += '%.3E, '%(float(a))
					except:
						DATA += '{}, '.format(a)
				DATA += '\n'

			if not result:
				print('{}, {} Fail!'.format(i, process[1]))
				self.errorcode = self.errorcode_list[len(DATA.split('\n'))-2]
				print('Errorcode:', self.errorcode )
				try:
					showinfo('message', '{} Fail!'.format(process[2]))
				except:
					showinfo('message', '{} Check Fail!'.format(process[1].split('/')[1]))
				break
		self.comport.close()
		self.DATA = DATA
		return self.errorcode, self.DATA

	# 回傳測試結果(1,0,-1), 測試值 --> 1:pass , 0:fail, -1:error
	# 如果有意外狀況,回傳 -1, Error message
	def deviceread(self, command):
		value = self.comport.readline().decode().strip()
		if value == '':
			print('Device Data timeout...')
			return -1, 'Device Data timeout...'
		try:
			command = command.split('/')
			print(command)
			if command[0] == "result":
				if value != command[1]:
					return 0, value
			elif command[0] == "limit":
				if command[1] != '':
					if not float(command[1]) <= float(value):
						return 0, value
				if command[2] != '':
					if not float(value) <= float(command[2]):
						return 0, value
				# if not float(command[1]) <= float(value) <= float(command[2]):
				# 	return 0, value
			elif command[0] == "pass":
				return 1, value
		except:
			message = traceback.format_exc()
			print(message)
			return -1, message
		return 1, value

	def devicesleep(self, command):
		time.sleep(float(command))
		return 1, None

	def devicewrite(self, command):
		try:
			if self.comport.writable:
				command += '\n'
				self.comport.write(command.encode())
			else:
				return -1, 'Comport not writable!'

			return 1, command[:-2]

		except:
			return -1, traceback.format_exc()

	def devicecheck(self, command):
		command = command.split('/')
		for i in range(5):
			ret, value = self.devicewrite(command[0])
			if ret == -1:
				return -1, message
			value = self.comport.readline().decode().strip()
			print('check value:', value)
	
			if value==command[1]:
				return 1, None
			else:
				self.devicewrite(command[2])

		return -1, "Check device setting Fail!"

preTest_func = serialFunction('preTest.ini', ['FAIL'], ps.CHROMA_com,
ps.CHROMA_baud, ps.CHROMA_timeout, bytesize=ps.CHROMA_bytesize,
parity=ps.CHROMA_parity)

IR_func = serialFunction('IR.ini', ps.IR_errorcode, ps.CHROMA_com,
ps.CHROMA_baud, ps.CHROMA_timeout, bytesize=ps.CHROMA_bytesize,
parity=ps.CHROMA_parity)

Hipot_func = serialFunction('Hipot.ini', ps.Hipot_errorcode, ps.CHROMA_com,
ps.CHROMA_baud, ps.CHROMA_timeout, bytesize=ps.CHROMA_bytesize,
parity=ps.CHROMA_parity)

Resistance_7_8_10_11 = RES_7_8_10_11(myins, dr)
Resistance_1_2_3 = RES_1_2_3(myins, dr)
Resistance_9 = RES_9(myins, dr)

# print(Resistance_7_8_10_11.start())

# print(Resistance_1_2_3.start())

# print(Hipot_func.start())

# print(IR_func.start())

if __name__ == '__main__':
	myins.close()
